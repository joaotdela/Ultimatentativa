package com.example.projetobike;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button btnvol = (Button) findViewById(R.id.btnvol);
        btnvol.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it2 = new Intent(getBaseContext(),MainActivity.class);
                startActivity(it2);
            }
        });
        Button btnpes =(Button) findViewById(R.id.bnpes);
        btnpes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent it3 = new Intent(getBaseContext(),MainActivity3.class);
                startActivity(it3);
            }
        });
    }
}